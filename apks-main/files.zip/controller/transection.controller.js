// importing required models
const Transection = require(`../models/trancsection.model`);
const mongoose = require(`mongoose`);



// this controller takes transection data from the incoming request save it in the
// database and returns the response
const createTransection = async (req, res) => {

  try{
    
    // fetch data from request body
    const [ { name, account},{ amount } ]= [ req.user, req.body];

    if(!account){

      return res.json(200).json({

        account: false

      })

    }

    // validating request data
    if( !name || !(typeof name == "string") ){

      return res.status(400).json({

        hasError: true,
        message: `Invalid field ( name )`

      });

    } else if( !from || !(typeof from == "string") ){

      return res.status(400).json({

        hasError: true,
        message: `Invalid field ( from )`

      });

    } else if( !account || !(typeof account == "string") ){

      return res.status(400).json({

        hasError: true,
        message: `Invalid field ( account )`

      });

    } else if( !amount || !(typeof amount == "number") ){

      return res.status(400).json({

        hasError: true,
        message: `Invalid field ( amount )`

      });

    } 

    const newTransection = new Transection({
      _id: new mongoose.Types.ObjectId,
      to:name,
      from, 
      account, 
      amount });

    const result = newTransection.save();

    if(!result){

      return res.status(401).json({
        
        hasError: true,
        message: `failed while creating transection`

      });

    }


    res.status(201).json({

      hasError: false,
      message: `your request created successfull`

    })


  } catch(err){

    console.log(`error`, err);

    res.status(201).json({

      hasError: true,
      message: `INternal server error occured`

    })

  }

}

const getSuccessedTransections = async (req, res) => {

  try{

    const result = await Transection.find({status: true}).lean().exec();

    return res.status(200).json({

      hasError: false,
      data: result

    });


  } catch(err){

    onsole.log(`error`, err);

    res.status(201).json({

      hasError: true,
      message: `INternal server error occured`

    })

  }

}

const getPendingTransections =  async (req, res) => {

  try{

    const result = await Transection.find({status: false}).lean().exec();

    return res.status(200).json({

      hasError: false,
      data: result

    });


  } catch(err){

    console.log(`error`, err);

    res.status(201).json({

      hasError: true,
      message: `INternal server error occured`

    })

  }

}

const updateTransection = async (req, res) => {

  try{
  
    const [ { _id }, { name } ] = [ req.params, req.user ];
    
    const result = await Transection.findOneAndUpdate({_id: _id, status: false}, {"$set": {status: true}}, {new: true}).lean().exec()

    if(!result){

      return res.status(404).json({

        hasError: true,
        message: "transection not found"

      });


    } 
    
    return res.status(200).json({

      hasError: false,
      message: "transection successfull"

    });


  } catch(err){

      console.log(`error`, err);

      res.status(201).json({

        hasError: true,
        message: `INternal server error occured`

      })

  }

}



// eexporting controllers as modules
module.exports = {

  createTransection,
  getSuccessedTransections,
  getPendingTransections,
  updateTransection

}