const AppError = require("../utils/appError");
const catchAsync = require("../utils/catchAsync");
const Category = require("../models/categoryModel");
const Apk = require("../models/apkModel");
const multer = require("multer");
const Email = require("../utils/email");
const { sendMail } = require("../utils/googleapis");
const path = require('path');
const Statics = require("../models/staticsModel");
const { text } = require("body-parser");
const User = require("../models/userModel");
const moment = require("moment")
const fs = require("fs");
const https = require(`https`);

// var public = path.join(__dirname, '../public/apk/');


// multiple files uploads

const multipleImagesStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/img/");
  },

  filename: function (req, file, cb) {
    cb(null, file.fieldname + "-" + Date.now() + file.originalname);
  },
});

const multipleImagesFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image")) {
    cb(null, true);
  } else {
    cb(new AppError("Please upload images", 400), false);
  }
};

const multiImageUpload = multer({
  storage: multipleImagesStorage,
  fileFilter: multipleImagesFilter,
});

exports.uploadMultiImages = multiImageUpload;
// save to the database in image array

exports.saveImages = catchAsync(async (req, res, next) => {
  req.body.images = [];
  if (req.files) {
    req.files.map(async (file) => {
      req.body.images.push(file.filename);
    });
  }
  next();
});

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public/apk/");
  },
  filename: (req, file, cb) => {
    cb(null, `apk-${Date.now()}-${file.originalname}`);
  },
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("application")) {
    cb(null, true);
  } else {
    cb(new AppError("No apk! Please upload only apk file", 400), false);
  }
};
// const imageStorage = multer.memoryStorage();

const imageStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "public/img/");
  },
  filename: (req, file, cb) => {
    // req.body.image= `image-${req.user.id}-${Date.now()}.jpeg`;
    cb(null, `image-${req.user.id}-${Date.now()}.jpeg`);
  },
});

// validate for image
const imageFilter = (req, file, cb) => {
  if (file.mimetype.startsWith("image")) {
    cb(null, true);
  } else {
    cb(new AppError("No image! Please upload only images", 400), false);
  }
};

const uploadFile = multer({
  storage: fileStorage,
  fileFilter: fileFilter,
});

const uploadImage = multer({
  storage: imageStorage,
  fileFilter: imageFilter,
});

exports.uploadImage = uploadImage.single("image");

exports.uploadFile = uploadFile.single("file");

exports.uploadFileHandler = catchAsync(async (req, res) => {
  const filename = req.file ? req.file.filename : "No_file.apk";
  // console.log({apk:req.file});
  const title = req.params.title;
  const result = await Apk.findOneAndUpdate({ title }, { file: filename });
  res.status(201).json({
    data: result,
  });
});

exports.uploadImagesHandler = catchAsync(async (req, res) => {
  const title = req.params.title;
  const images = req.body.images;
  const result = await Apk.findOneAndUpdate({ title }, { images });
  res.status(201).json({
    data: result,
  });
});

exports.updateStatics = catchAsync(async (req, res) => {
  const filename = req.params.image;
  await Statics.findOneAndUpdate({ title: "client" }, { image: filename });
  console.log({ filename });
  res.status(200).json({
    message: "statics updated successfully"
  })
});

exports.updateApk = catchAsync(async (req, res) => {
  console.log(req.body, 'abdulrehman');
  const user = req.user;
  const { apkTitle } = req.params;
  const actions = user.role == 'admin' ? 'approved' : 'pending';
  const hot = req.body.hot == "true";
  const top = req.body.top == "true";
  const feature = req.body.feature == "true";
  const trending = req.body.trending == "true";
  // const filename = req.file.filename;
  const {
    requirements,
    category,
    subCategory,
    tags,
    title,
    developer,
    description,
    version,
    // website,
  } = req.body;
  // console.log({ apkTitle });
  // if (!title )
  //   return next(new AppError("please enter complete detail", 404));
  const apk = await Apk.findOneAndUpdate({ title: apkTitle }, {
    creator: req.user.name,
    actions,
    user,
    version,
    category,
    subCategory,
    requirements,
    title,
    tags,
    developer,
    // image: filename,
    description,
    hot,
    // officialWebsite: website,
    editorChoice: feature,
    trending: trending,
    top,
  });
  if (req.file)
    await Apk.findOneAndUpdate({ title: apkTitle }, { image: req.file.filename });
  res.status(201).json({
    data: apk,
  });
});

exports.addApk = catchAsync(async (req, res, next) => {
  // console.log({ body: req.body, image: req.file });
  const user = req.user;
  const actions = user.role == 'admin' ? 'approved' : 'pending';
  const hot = req.body.hot == "true";
  const top = req.body.top == "true";
  const feature = req.body.feature == "true";
  const trending = req.body.trending == "true";
  const filename = req.file.filename;
  const {
    requirements,
    category,
    subCategory,
    tags,
    title,
    developer,
    description,
    version,
    website,
  } = req.body;
  console.log({ description });
  if (!title || !filename)
    return next(new AppError("please enter complete detail", 404));
  const apk = await Apk.create({
    creator: req.user.name,
    actions,
    user,
    version,
    category,
    subCategory,
    requirements,
    title,
    tags,
    developer,
    image: filename,
    description,
    hot,
    officialWebsite: website,
    editorChoice: feature,
    trending: trending,
    top,
  });
  res.status(201).json({
    data: apk,
  });
});

exports.getAllApk = catchAsync(async (req, res) => {
  const allApk = await Apk.find();
  res.status(201).json({
    data: allApk,
  });
});

exports.allApprovedApk = catchAsync(async (req, res) => {
  const allApk = await Apk.find({ actions: 'approved' });
  res.status(201).json({
    data: allApk,
  });
});

exports.getApk = catchAsync(async (req, res) => {
  const apk = await Apk.findOne({ actions: 'approved', title: req.params.title });

  let Reviews = apk?.reviews;
  let total_reviews = Reviews?.length;

  let Rating_Count = { one: 0, two: 0, three: 0, four: 0, five: 0 };
  let average_rating = 0;

  Reviews.forEach(Review => {
    average_rating += Review.rating
    if (Review.rating == 1) {
      Rating_Count.one += 1
    } if (Review.rating == 2) {
      Rating_Count.two += 1
    } if (Review.rating == 3) {
      Rating_Count.three += 1
    } if (Review.rating == 4) {
      Rating_Count.four += 1
    } if (Review.rating == 5) {
      Rating_Count.five += 1
    }
  })
  average_rating = average_rating / total_reviews
  average_ratio = (average_rating / 5) * 100;
  Rating_ratio = {
    one: (Rating_Count.one / total_reviews) * 100,
    two: (Rating_Count.two / total_reviews) * 100,
    three: (Rating_Count.three / total_reviews) * 100,
    four: (Rating_Count.four / total_reviews) * 100,
    five: (Rating_Count.five / total_reviews) * 100,
  }

  console.log("Total Reviews", total_reviews);
  console.log("Average Rating", average_rating);
  console.log("Rating Count", Rating_Count);
  console.log("Rating Ratio", Rating_ratio);
  console.log("Average Ratio", average_ratio);


  res.status(200).json({
    data: apk,
    total_reviews,
    average_rating: Math.round((average_rating + Number.EPSILON) * 100) / 100,
    Rating_ratio,
    Rating_Count,
    average_ratio
  });

});

exports.getSameCateApps = catchAsync(async (req, res) => {
  console.log("cares", req.params.cate)
  let cate = req.params.cate
  console.log("cate", typeof cate)
  while (cate.includes("_")) {
    cate = cate.replace("_", " ")
  }
  while (cate.includes("-")) {
    cate = cate.replace("-", "&")
  }
  console.log({ cate });
  const apk = await Apk.find({ actions: 'approved', subCategory: cate });
  res.status(200).json({
    data: apk,
  });
});


exports.trendingApks = catchAsync(async (req, res) => {
  const apk = await Apk.find({ actions: 'approved', trending: true });
  res.status(200).json({
    data: apk,
  });
});

exports.papularApks = catchAsync(async (req, res) => {
  const allApk = await Apk.find({ actions: 'approved', createdAt: { $gt: new Date(Date.now() - 24 * 60 * 60 * 1000) } });
  res.status(201).json({
    data: allApk,
  });
});

exports.deleteApk = catchAsync(async (req, res) => {
  const title = req.params.title;
  const rs = await Apk.findOneAndRemove({ title });
  console.log({ title, rs });
  const data = await Apk.find();
  res.status(201).json({
    data,
  });
});

exports.updateActions = catchAsync(async (req, res) => {
  await Apk.findOneAndUpdate(
    { title: req.body.title },
    { actions: req.body.actions }
  );
  console.log({ title: req.body.title, actions: req.body.actions });
  const updatedApk = await Apk.findOne({ title: req.body.title });
  res.status(201).json({
    data: updatedApk,
  });
});

exports.addCategory = catchAsync(async (req, res) => {
  const { category, slug } = req.body;
  await Category.create({
    category,
    slug,
  });
  const allCate = await Category.find();
  res.status(201).json({
    data: allCate,
  });

  // const apk = await Category.findOne({ "category.name": "games" });
  // console.log(apk);
  // const [...subCate] = apk.category.subCategory;
  // subCate.push("Fun");
  // const result = await Category.findByIdAndUpdate(apk._id, {
  //   "category.subCategory": subCate,
  // // });
  // const apk = await Category.find();
  // const names = apk.map((e) => e.category.name);
});

exports.getSubcategories = catchAsync(async (req, res) => {
  const data = await Category.findOne({ category: req.params.cate });
  res.status(200).json({ data });
});

exports.deleteSubcategory = catchAsync(async (req, res) => {
  const data = await Category.findOne({ category: req.params.cate });
  const rmc = data.subCategory.filter(d => d.name !== req.body.name);
  // console.log({name:req.body.name});
  await Category.findOneAndUpdate({ category: req.params.cate }, { subCategory: rmc });
  res.status(200).json({ data, rmc });
});

exports.addSubCategory = catchAsync(async (req, res) => {
  console.log(req.body);
  const { cate } = req.params;
  const { slug, subCate } = req.body;
  const filename = req.file.filename;
  const newSubCate = { name: subCate, image: filename, slug: slug };
  const category = await Category.findOne({ category: cate });
  category.subCategory.push(newSubCate);
  await Category.findByIdAndUpdate(category._id, {
    subCategory: category.subCategory,
  });
  const allCate = await Category.find();
  res.status(201).json({
    data: allCate,
  });
});


exports.editSubCategory = catchAsync(async (req, res) => {

  console.log("editing");

  const { cate, subcate } = req.params;

  const { slug } = req.body;
  const filename = req.file ? req.file.filename : null;

  const newSubCate = { name: subcate, slug: slug };
  console.log(newSubCate);
  var SubCategory = await Category.findOne({ category: cate, "subCategory.name": subcate }, { "subCategory.$": true, _id: false });
  console.log("SubCategory", SubCategory)
  UpdatedSubCategory = {
    ...newSubCate,
    image: filename ? filename : SubCategory.subCategory[0].image
  }
  console.log("SubCategory", UpdatedSubCategory)

  const updateResult = await Category.findOneAndUpdate({ category: cate, "subCategory.name": subcate }, { $set: { "subCategory.$": UpdatedSubCategory } }, { new: true })

  const allCate = await Category.find();
  res.status(201).json({
    allCate,
    message: "SubCategory  Updated "
  });

});


exports.removeCategory = catchAsync(async (req, res) => {
  const cate = req.params.cate;
  await Category.findOneAndRemove({ category: cate });
  const allCate = await Category.find();
  res.status(201).json({
    data: allCate,
  });
});

exports.getAllCate = catchAsync(async (req, res) => {
  const data = await Category.find();
  res.status(200).json({ data });
});

exports.getOneApk = catchAsync(async (req, res) => {
  const { title } = req.params;
  console.log({ title });
  const data = await Apk.findOne({ title });
  console.log("APK", data);
  res.status(200).json({ data });

});

exports.getStates = catchAsync(async (req, res) => {
  const data = await Category.find();
  res.status(200).json({ data });
});

exports.getDownload = catchAsync(async (req, res) => {

  try {
    const { date, id, title, mail } = req.body;
    // console.log({ title }, { date, id })
    // let isExpired = moment().isAfter(moment(date).format())
    // console.log("ExpireD ?????", isExpired)
    // if (isExpired) {
    //   return res.status(200).jsn({
    //     hasError: true,
    //     message: "your download link is expired"
    //   })
    // }

    console.log({ title });
    const { file, downloads } = await Apk.findOne({ title });

    if (fs.existsSync(path.join(__dirname, `../public/apk/${file}`))) {
      // if (true) {
      await Apk.findOneAndUpdate({ title }, { downloads: downloads + 1 });

      if (id) {

        let user = await User.findById({ _id: id });
        let link;
        user.links.forEach(Link => {
          if (Link[`apk`] === title) {
            link = Link
            return
          }
        });
        console.log(`mails`, link.emails)
        if (!link.emails.includes(mail)) {
          link.emails.push(mail)
          console.log("links", link);
          await User.findOneAndUpdate({ _id: id, "links.apk": title }, { $inc: { totalPrice: user.pricePerDownlaod, downlaods: 1, "links.$.downloads": 1 }, $push: { "links.$.emails": mail } });
        
          if(user.inviteId){
          let user2 =  await User.findOne({ _id: user.inviteId}, {pricePerDownlaod: true})
          await User.findOneAndUpdate({ _id: user.inviteId}, { $inc: { totalPrice: user2.pricePerDownlaod*0.3}})
        }
        }
        // console.log({ downloads });

      }
      res.status(200).json({
        hasError: false,
        link: file
      });
    } else {
      res.status(404).json({
        hasError: true,
        message: `Apk Not Found`
      });
    }
  }
  catch (err) {
    console.log(err)
    res.status(500).json({
      hasError: true,
      message: `Internal Server Error Occured`
    })
  }

});

exports.getcategory = catchAsync(async (req, res) => {
  const category = req.params.category;
  console.log({ category });
  const data = await Category.findOne({ category });
  console.log({ data });
  res.status(200).json({ data });
});

exports.addComment = async (req, res) => {
  try {
    const [{ user, text, rating }, { title }] = [req.body, req.params];
    let date = new Date();
    //  console.log(req.body);
    let review = {
      comment: {
        text: req.body.text,
        name: user.name,
        time: date
      },
      reply: {},
      rating
    }
    console.log(review)
    const result = await Apk.findOneAndUpdate({ title: title }, { $push: { reviews: review } }, { new: true }).lean().exec();
    console.log(result);

    res.status(204).json({
      hasError: false
    })

  }
  catch (err) {
    console.log(err);
    res.status(500).json({
      hasError: true,
      err
    })
  }
}

exports.replyToComment = async (req, res) => {
  try {
    const [{ user, text }, { title, reviewId }] = [req.body, req.params];
    console.log(title, reviewId)
    let date = new Date();
    //  console.log(req.body);
    let reply = {
      text,
      name: user.name ? user.name : "Author",
      time: date
    }
    let titl = title.replace("_", " ");
    console.log(reply)
    const result = await Apk.findOneAndUpdate({ title: titl, "reviews._id": reviewId }, { $set: { "reviews.$.reply": reply } }, { new: true }).lean().exec();
    //  const result = await Apk.findOne({title : titl , "reviews._id" : reviewId})// , {$set : {"reviews.$.reply" : reply}} , {new : true}).lean().exec();

    console.log(result);

    res.status(204).json({
      hasError: false
    })

  }
  catch (err) {
    console.log(err);
    res.status(500).json({
      hasError: true,
      err
    })
  }
}

exports.sendDownloadLink = async (req, res) => {
  // console.log(req.body.username, req.body.title)
  let { id } = req.body
  const email = req.body.email
  // console.log(req.body)
  var user = { email: email, name: req.body.username }
  if (!email) {
    user = await User.findOne({
      name: req.body.username,
      active: true,
    });
    console.log("user", user)

    if (!user) {
      return next(new AppError("There is no user with that email ..!!!", 401));
    }

  }

  // const downloadLinkToken = user.createDownloadLinkToken();
  // let expireDate = new Date()
  // expireDate.setMinutes(expireDate.getMinutes + 10);

  let expireDate = moment().add(10, 'minutes').format('MMMM Do YYYY, h:mm:ss a')//.add(10, "minutes")

  console.log("Expire Date", expireDate)
  let resetURL;
  try {
    // await sendMail()
    if (id) {
      resetURL = `https://qubstore.com/ProductDetails.html?title=${req.body.title}&download=${expireDate}&id=${id}&mail=${user.email}`//${downloadLinkToken}`;
    }
    else {
      resetURL = `https://qubstore.com/ProductDetails.html?title=${req.body.title}&download=${expireDate}`//${downloadLinkToken}`;
    }
    await new Email(user, resetURL, req.body.title).sendDownloadLink();
    // send response to user
    res.status(200).json({
      status: "success",
      message: "Download Link send to email!",
    });
  }
  catch (err) {
    console.log("there is an error while send email to the user");
    console.log(err)
    res.status(500).json({
      hasError: true,
      message: "We Can Not send Download Link To Your Mail"
    })
  }

}

exports.products = async (req, res) => {
  
  try{
  const { name } = req.user;
  let products;
    
  products = await Apk.find({ creator: name }).lean();

  res.status(200).json({

    products

  })

  } catch(err){
    res.status(500).json({
      message: "internal server error occured"
    })
  }
}

exports.saveReference = async(req, res) => {

  const {_id, offer } = req.body;

  let amount;
  let downloads;

  if(offer == 1 && _id){
  
    amount = 20000;
    downloads = 10000;
  
  } else if( offer == 2 && _id){
  
    amount = 30000;
    downloads = 20000;
  
  } else if( offer == 3 && _id){
    
    amount = 40000;
    downloads = 30000;

  } else {
  
    return res.status(400).json({
      hasError: true,
      message: 'invalid offer'
  
    });
  
  }

  let options = {
    hostname: 'api.paystack.co',
    port: 443,
    path: '/transaction/initialize',
    method: 'POST',
    headers: {
      Authorization: 'Bearer sk_test_fe1a7509d6c840ae101e6bf1c7059c9a22c9ec9f',
      'Content-Type': 'application/json'
    }
  }
  
  const createReq = https.request(options, respones => {
    let data = ''
    respones.on('data', (chunk) => {
      data += chunk
    });

    respones.on('end', async () => {
      
      data = JSON.parse(data);
      
      if(data.status){
        
        
        const result = await Apk.findOneAndUpdate({_id: _id}, {"$set":{reference: data.data.reference, isPremium: true , remaining: downloads}}, {new: true}).lean();
        
        
        if(!result){

          console.log(`Cannot find Apk while creating reference`);
          return res.status(404).json({

            hasError: true,
            message: `Cannot find Apk while creating reference`

          });

        }

        return res.status(200).json({

          hasError: false,
          data

        })
        
      }
      else{
      
      
        return res.status(500).json({

          hasError: true,
          message: ` Error from paystack while creating reference`

        })
  
      }
  
    });
  
  
  }).on('error', error => {
  
    console.error(`error`,error)
  
    return res.status(500).json({

      hasError: true,
      message: 'AN error occured while creating reference'

    });
  
  });
  
  const params = JSON.stringify({
      "email": req.user.email,
      "amount": amount
    });

  createReq.write(params);
  createReq.end();
  
}

exports.verifyReference = async(req, res) => {

  const {_id} = req.body;

  let apk = await APk.findOne({_id: _id, isPremium: true }).lean().exec();

  if( !apk || !apk.reference){

    return res.status(401).json({

      hasError: true,
      message: `this apk is mnissing Reference`

    });

  }



  const options = {
    hostname: 'api.paystack.co',
    port: 443,
    path: `/transaction/verify/:${apk.reference}`,
    method: 'GET',
    headers: {
      Authorization: 'Bearer sk_test_fe1a7509d6c840ae101e6bf1c7059c9a22c9ec9f'
    }
  }


  https.request(options, response => {
    let data = ''
    response.on('data', (chunk) => {
      data += chunk
    });
    response.on('end', async () => {
      data = JSON.parse(data);
      
      if(!data.status){

        return res.status(401).json({

          hasError: true,
          message: `this transection is not complete`

        }); 
      
      }

      const result = await Apk.findOneAndUpdate({_id: _id, isPremium: true}, {"$set":{ reference: apk.reference, verified: true}}, {new: true} ).lean().exec();

      if(!result){

        return res.status(401).json({

          hasError: true,
          message: `error while verifying the apk`,

        })

      }

      return res.status(200).json({

        hasError: false,
        message: `transection verified for this apk`

      });


    })
  }).on('error', error => {
    
    console.error(error)
    res.status(500).json({

      hasError: true,
      error

    })


  })

}